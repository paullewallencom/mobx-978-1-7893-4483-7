import React from 'react';
import ReactDOM from 'react-dom';
import { MobXBookApp } from './core/app';

ReactDOM.render(<MobXBookApp />, document.getElementById('root'));
